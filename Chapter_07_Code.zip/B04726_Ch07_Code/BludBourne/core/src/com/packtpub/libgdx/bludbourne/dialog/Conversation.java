package com.packtpub.libgdx.bludbourne.dialog;

public class Conversation {
    private String id;
    private String dialog = "";

    public Conversation(){
    }

    public String getId() {
        return id;
    }

    public void setId(String id){
        this.id = id;
    }

    public String getDialog(){
        return dialog;
    }

    public void setDialog(String dialog){
        this.dialog = dialog;
    }

}
